package com.example.deustobank;

import com.example.deustobank.model.Account;
import com.example.deustobank.model.User;
import com.example.deustobank.repository.AccountRepository;
import com.example.deustobank.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class AccountControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountRepository accountRepository;

    private String baseUrl;
    private Long testUserId;
    private Long testAccountId;

    @BeforeEach
    void setUp() {
        baseUrl = "http://localhost:" + port;
        
        // Limpiar datos de tests anteriores
        accountRepository.deleteAll();
        userRepository.deleteAll();

        // Crear usuario de prueba
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("password123");
        user.setDni("12345678A");
        user.setFullName("Test User");
        user.setRole("USER");
        user.setActive(true);
        testUserId = userRepository.save(user).getId();

        // Crear cuenta de prueba
        Account account = new Account();
        account.setOwnerName("Test User");
        account.setBalance(100.0);
        account.setUser(user);
        testAccountId = accountRepository.save(account).getId();
    }

    @Test
    void testFullAccountLifecycle() {
        // 1. Obtener todas las cuentas (debería tener 1)
        ResponseEntity<Account[]> response1 = restTemplate.getForEntity(
            baseUrl + "/accounts", 
            Account[].class
        );
        assertEquals(HttpStatus.OK, response1.getStatusCode());
        assertNotNull(response1.getBody());
        assertEquals(1, response1.getBody().length);

        // 2. Obtener cuenta por ID
        ResponseEntity<Account> response2 = restTemplate.getForEntity(
            baseUrl + "/accounts/" + testAccountId, 
            Account.class
        );
        assertEquals(HttpStatus.OK, response2.getStatusCode());
        assertNotNull(response2.getBody());
        assertEquals(100.0, response2.getBody().getBalance());

        // 3. Obtener cuentas por usuario
        ResponseEntity<Account[]> response3 = restTemplate.getForEntity(
            baseUrl + "/accounts/user/" + testUserId, 
            Account[].class
        );
        assertEquals(HttpStatus.OK, response3.getStatusCode());
        assertNotNull(response3.getBody());
        assertEquals(1, response3.getBody().length);

        // 4. Realizar un depósito
        restTemplate.put(
            baseUrl + "/accounts/" + testAccountId + "/deposit?amount=50&requesterId=" + testUserId,
            null
        );

        // Verificar que el saldo aumentó
        ResponseEntity<Account> response4 = restTemplate.getForEntity(
            baseUrl + "/accounts/" + testAccountId, 
            Account.class
        );
        assertEquals(HttpStatus.OK, response4.getStatusCode());
        assertEquals(150.0, response4.getBody().getBalance());

        // 5. Realizar una retirada
        restTemplate.put(
            baseUrl + "/accounts/" + testAccountId + "/withdraw?amount=30&requesterId=" + testUserId,
            null
        );

        // Verificar que el saldo disminuyó
        ResponseEntity<Account> response5 = restTemplate.getForEntity(
            baseUrl + "/accounts/" + testAccountId, 
            Account.class
        );
        assertEquals(HttpStatus.OK, response5.getStatusCode());
        assertEquals(120.0, response5.getBody().getBalance());
    }

    @Test
    void testDepositInvalidAmount() {
        // Intentar depósito con cantidad negativa
        restTemplate.put(
            baseUrl + "/accounts/" + testAccountId + "/deposit?amount=-10&requesterId=" + testUserId,
            null
        );

        // Verificar que el saldo no cambió
        ResponseEntity<Account> response = restTemplate.getForEntity(
            baseUrl + "/accounts/" + testAccountId, 
            Account.class
        );
        assertEquals(100.0, response.getBody().getBalance());
    }

    @Test
    void testWithdrawExceedsBalance() {
        // Intentar retirar más de lo que hay
        restTemplate.put(
            baseUrl + "/accounts/" + testAccountId + "/withdraw?amount=200&requesterId=" + testUserId,
            null
        );

        // Verificar que el saldo no cambió
        ResponseEntity<Account> response = restTemplate.getForEntity(
            baseUrl + "/accounts/" + testAccountId, 
            Account.class
        );
        assertEquals(100.0, response.getBody().getBalance());
    }
}